<?php
//must use single quotes
//server name, login, password
//mysql_connect('127.0.0.1:8889','root','root');
//database name
//mysql_select_db('ih_db');

$dbHost = "localhost";
$dbUsername = "root";
$dbPassword = "root";
$dbName = "ih_db";

//$link = mysqli_connect("localhost", "arensel", "salad", "arensel_1008");
