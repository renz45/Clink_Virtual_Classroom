<?php
/**
 * 
 * This function will autoload any classes instantiated. A specific naming convention must be followed in order
 * for this to work, class names need to be based off of their location. For example, a class contained within
 * the folder phpLib/myClass.php must have the name of phpLib_myClass within the myClass.php file.  The name 
 * reflects the class location.
 * 
 * This file needs to be required in all other files which call a class.
 * 
 * phpLib/myClass.php - name would be [phpLib_myClass] - instantiated by [$class = new phpLib_myClass();]
 * 
 * php will pass in a class for an argument which has not been included manually as a last resort before
 * an error is thrown.
 * @param $class
 */
function __autoload($class)
{
	set_include_path($_SERVER['DOCUMENT_ROOT']);
	$parts = explode('_',$class);
	$path = implode(DIRECTORY_SEPARATOR, $parts);
	
	require_once $path . '.php';
}