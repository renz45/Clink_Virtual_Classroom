<?php
set_include_path($_SERVER['DOCUMENT_ROOT']);
//require 'php/db.php';
include 'php/initClasses.php';

//navigation lists
$adminNavList = array('BLOG'=>'index.php',
			 	      'ABOUT'=>'about.php',
				      'OFFERINGS'=>'products.php',
				      'NEWSLETTER'=>'services.php',
				      'SETTINGS'=>'admin_settings.php');

$blogSubNavList = array('Add Post'=>'admin_blog_add.php',
				        'View Post'=>'admin_blog_view.php');