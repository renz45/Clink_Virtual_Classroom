<?php
set_include_path($_SERVER['DOCUMENT_ROOT']);
require_once 'php/required.php';

if(isset($_POST)){
	
	//add new post to db
	if($_POST['button'] == "Add Post"){
		//instantiate blogModel
		$blogModel = new model_blog();
		
		$errors = array();
		if(empty($_POST['title'])){
			array_push($errors, 'title');
		}
		if(empty($_POST['content'])){
			array_push($errors, 'content');
		}
		
		if(empty($_POST['category_id'])){
			$_POST['category_id'] = 0;
		}
		
		//create new VO_post value object
		$post = new VO_post();
		//set properties
		$post->title = $_POST['title'];
		$post->content = $_POST['content'];
		$post->userId = (INT)$_POST['user_id'];
		$post->tagList = explode(",",$_POST['tag_id']);
		$post->categoryId = (INT)$_POST['category_id'];
		
		//send the $post object to the addMost method of the blog model
		if(count($errors) > 0){
			$errors = implode(",", $errors);
			session_start();
			session_regenerate_id();
			$_SESSION['savedPost'] = $post;
			
			header('Location: ../../admin_blog_add.php?error='.$errors);
		}else{
			try {
				$blogModel->addPost($post);
				//redirect back to the add post page
				header('Location: ../../admin_blog_add.php?postAdded=true');
			} catch (Exception $e) {
				session_start();
				session_regenerate_id();
				$_SESSION['savedPost'] = $post;
				header('Location: ../../admin_blog_add.php?error=post');
			}//end catch
		}//end else

	}//end if($_POST['button'] == "Add Post")
	
	
	//TODO create post editing functionality
	if($_POST['button'] == "Edit Post"){
		
	}//end if($_POST['button'] == "Edit Post")
	
}//end if isset($_POST)

