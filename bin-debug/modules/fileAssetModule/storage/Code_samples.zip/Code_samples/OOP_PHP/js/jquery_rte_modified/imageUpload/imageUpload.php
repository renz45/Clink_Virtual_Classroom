

<html>
	<head>
		<link type="text/css" href="css/jquery.Jcrop.css" rel="stylesheet" />
		<link type="text/css" href="css/custom-theme/jquery-ui-1.8.6.custom.css" rel="stylesheet" />
	
		<script type='text/javascript' src='js/jquery-1.4.3.min.js'></script>
		<script type='text/javascript' src='js/jquery.Jcrop.min.js'></script>
		<script type='text/javascript' src='js/imageUpload.js'></script>
	</head>
	<body>
<?php
require('image.php');
//******** START SETTINGS ****************//

$up_size = 500; //upload size in KB
$img_path = "upload";  //url where the images are stored
$addedToName = time().rand(100,100000); //This gets added on after each picture to make the file name unique, some sort of random
				   //name is advised, ex:  time().rand()

$imgDisplayWidth = 400; //image displayed before cropping, sets max values, will shrink to the largest side
$imgDisplayHeight = 400;

$finalWidth = 100; // Final image size size eg 170px wide 140px height
$finalHeight = 100;

$cropOnly = true; //sets to only crop and not resize, this will ignore the final height and final width properties


//******* END SETTINGS ********************//
$path = getcwd()."/".$img_path;
if(!empty($_FILES))
{
	if (($_FILES["file"]["type"] == "image/gif")|| 
		($_FILES["file"]["type"] == "image/jpeg")|| 
		($_FILES["file"]["type"] == "image/pjpeg") || 
		($_FILES["file"]["type"] == "image/png"))
	{
	 	
		move_uploaded_file($_FILES["file"]["tmp_name"], $path . "/" . strtolower(str_replace(' ', '_', $_FILES["file"]["name"])));
		$file = $_FILES["file"]["name"];
		$dir = "$img_path/";
		
		$name = $dir.$file;
		$name = strtolower(str_replace(' ', '_', $name));
		
		$img = new Image($name);
		
		if(($img->getWidth()) > $imgDisplayWidth)
		{
			$img->resize($imgDisplayWidth,0);
		}elseif(($img->getHeight()) > $imgDisplayHeight){
			$img->resize(0,$imgDisplayHeight);
		} 
		
		$imgWidth = $img->getWidth();
		$imgHeight = $img->getHeight();
		
		unlink($name);
		$img->save($name,true);
		
		$img = NULL;
		
		
		echo "<div style='position:relative;'>
				<img id='imageToBeCropped' src='$name' width='$imgWidth' height='$imgHeight' />
				
				<div style='margin-top:15px;'>
					<!-- <div style='width:".$finalWidth."px;height:".$finalHeight."px;overflow:hidden;'>
						<img src=\"$name\" id='preview' />
						
					</div> -->
					<!-- <p style='font-size:9px;'>Preview, final image will be $finalWidth x $finalHeight pixels.</p> -->
					<a class='image_upload_submit_button' id='savePicture' href=\"imageUpload.php?save=$name\">save</a> &nbsp; <a class='image_upload_submit_button' id='deletePicture' href=\"imageUpload.php?delete=$name\">discard</a></p>
				</div>
			  </div>
			  <p>Drag to crop the image.</p>";
		/*echo "<div style='width:100px;height:100px;overflow:hidden;'>
			<img src=\"$name\" id='preview' />
		</div>";*/
		//echo "<a class='submit_button' id='savePicture' href=\"imageUpload.php?save=$name\">save</a> | <a class='submit_button' id='deletePicture' href=\"imageUpload.php?delete=$name\">discard</a></p>";

	}//end if
}//end if
	
if(!empty($_GET['save']))
{
	print_r($_GET);
	$img2 = new Image($_GET['save']);
	//crop
	if(isset($_GET['x1']))
	{
		if($_GET['w'] == 0 && $_GET['h'] == 0 && !$cropOnly)
		{
			$img2->crop($_GET['x1'], $_GET['y1'],$_GET['x1'] + $finalWidth,$_GET['y1'] + $finalHeight);
		}elseif( $_GET['w'] != 0 && $_GET['h'] != 0){
			$img2->crop($_GET['x1'], $_GET['y1'], $_GET['x2'], $_GET['y2']);
		}
		unlink($_GET['save']);
	}elseif(!$cropOnly){
		$img2->crop(0, 0, $finalWidth, $finalHeight);
		unlink($_GET['save']);
	}else{
		unlink($_GET['save']);
	}
	
	//resize
	if(!$cropOnly)
	{
		$img2->save($_GET['save'],true);
		$img2 = new Image($_GET['save']);
		$img2->resize($finalWidth, $finalHeight, false);
		unlink($_GET['save']);
	}
	
	//strip out file extension
	$imageStartName = preg_replace("/\\.[^.\\s]{3,4}$/", "", ($_GET['save']));
	
	$img2->save("$imageStartName-$addedToName.jpg",true);
	
	echo "<p id=\"finalImageNameIframe\">$imageStartName-$addedToName.jpg</p>";
}

if(!empty($_GET['delete']))
{
	unlink($_GET['delete']);
}
?>
</body></html>