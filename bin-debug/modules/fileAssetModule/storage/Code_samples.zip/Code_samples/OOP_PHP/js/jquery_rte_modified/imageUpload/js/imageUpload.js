$(function(){
	
	
				
			
				/*$('#savePicture').bind('click',function(){
					console.log('click save');
					return false;
				});*/
				
				$('#imageToBeCropped').Jcrop({
		            onSelect:    showPreview,
		            onChange:    showPreview/*,
		           
		            aspectRatio: 1 */
		        });
				
				function showCoords(c)
				{
					/*console.log(c.x);
					console.log(c.y);
					console.log(c.x2);
					console.log(c.y2);
					console.log(c.w);
					console.log(c.h);
					console.log('************');*/
					
				};
				
				
				function showPreview(coords)
				{
					var rx = 100 / coords.w;
					var ry = 100 / coords.h;
					
					var cx = $('#imageToBeCropped').attr('width');
					var cy = $('#imageToBeCropped').attr('height');
					$('#preview').css({
						width: Math.round(rx * cx) + 'px',
						height: Math.round(ry * cy) + 'px',
						marginLeft: '-' + Math.round(rx * coords.x) + 'px',
						marginTop: '-' + Math.round(ry * coords.y) + 'px'
					});
					
					
						
						var currentGetVars = $('#savePicture').attr('href');
						finalGetVars = currentGetVars + "&x1="+coords.x+ 
											  "&y1="+coords.y+
											  "&x2="+coords.x2+
											  "&y2="+coords.y2+
											  "&w="+coords.w+
											  "&h="+coords.h;

						
				};
				
				$('#savePicture').bind('click',function(){
					
					if(typeof(finalGetVars) != "undefined"){
						$(this).attr('href',finalGetVars);
					}else{
						$(this).attr('href',$('#savePicture').attr('href'));
					}
					
				});


				
});//end file