//This file controls the interface elements on the AdminBlogAddPost.php page.
//adds the functionality to custom dropdown, custom select list
//adds ajax to the add category/tag forms which are inserted with jquery


$(function(){
	
	//category Selector
	var catList = $("#category_selector").find("ul");
	
	//adjusts the size of the dropdown depending on how many categories there are
	var categoryListHeight = $("#category_selector li a").height();
	var numCategories = $("#category_selector li a").length;
	var maxNumCategories = 6;
	
	var categoryListMaxHeight = 120;
	
	if(numCategories <= maxNumCategories){
		categoryListMaxHeight = numCategories * categoryListHeight;
	}else{
		categoryListMaxHeight = categoryListHeight * maxNumCategories;
	};
	
	
	//function that toggles the visibility of the category selector, animates open and closed
	var catListToggle = function(closeOnly){
		if(catList.height() > 0){
			catList.animate({"height":"0px"},'fast',function(){
				catList.removeClass("open");
			});
		}else if(!closeOnly){
			catList.addClass("open");
			catList.animate({"height":categoryListMaxHeight+"px"},'fast');
		}
	};
	
	
	//when the page loads the category select will pick its default setting based on which post has been added in, if any
	var currentPostCategory = $("#hiddenCategoryId").attr("value");
	if(currentPostCategory){
		$("#current_category").html($("#category_"+currentPostCategory).html());
	}//end if
	
	
	//add click functionality to the category selector
	$("#current_category").bind("click",function(){
		catListToggle();
		
		return false;
	});//end bind
	
	//closes dropdown when the mouse leaves the dropdown
	$("#category_selector").bind("mouseleave",function(){
		
		catListToggle(true);
	});//end bind
	
	//when an item is clicked the main title is changed to that item and the hiddenCategoryId input value is changed to the corrosponding id
	var bindCatListItems = function(){
		$("#category_selector li a").bind("click",function(){
			var that = this;
			$("#current_category").fadeOut(300,function(){
				
				$("#current_category").html($(that).html());
				$("#current_category").fadeIn(300);
			});//end fadeOut
				
			catListToggle();
			
			//filters the number out of the string that is the id on the category list
			//set the hidden input to the correct id, tag and category ids need to be formated: tag_1, tag_2, category_1, category_2.  Label and number seperated by '_'
			var selectedId = $(this).attr('id');
			var filteredId = selectedId.split("_");
			
			//sets hidden input with id of hiddenCategoryId value to the corrosponding id
			$("#hiddenCategoryId").attr('value',filteredId[1]);
			
			return false;
		});//end bind
	};//end bindCatListItems
	bindCatListItems();
	//end category selector
	
	
	
	
	//tag selector
	//adjusts tag selector height based on number of items that are in it
	var numTags = $('#item_selector ul li').length;
	var liHeight = $('#item_selector ul li').height();
	var maxTagListHeight = 9;
	
	if(numTags <= maxTagListHeight){
		$('#item_selector ul').height(numTags * liHeight);
	}else{
		$('#item_selector ul').height(maxTagListHeight * liHeight);
	};//end if
	
	//selects items in the list if they exist in the hiddenTagId input already
	var existingList = ($('#hiddenTagId').attr('value')).split(',');
	var startingTagList = $('#item_selector li a');
	startingTagList.each(function(index){
		//takes the current item at startingTagList[index] splits the string and extracts only the number, than looks for an index in the existing list, if it finds an
		//index it adds the selected class to the list item.
		if(existingList.indexOf($(startingTagList[index]).attr('id').split('_')[1]) > -1){
			$(startingTagList[index]).addClass('selected');
		};//end if
	});//end each
	
	//add click functionality
	var bindTagListItems = function(){
		$('#item_selector li a').bind('click',function(){
			$(this).fadeOut(200,function(){
				$(this).toggleClass('selected');
				$(this).fadeIn(100,function(){
					
					//loop through items with the selected class, split off the tag part of the name and push only the number into an array
					var selectedTags = $('#item_selector li a.selected');
					var tagIdList = [];
					selectedTags.each(function(index){
						var tagId = ($(selectedTags[index]).attr('id').split("_"))[1];
						tagIdList.push(tagId);
					});//end selectedTags
					
					//convert the array of tag ids into a string seperated by commas
					var tagListString = tagIdList.join(',');
					
					//send the comma seperated string of ids to the hidden field of the post form with id of hiddenTagId
					$('#hiddenTagId').attr('value',tagListString);
			
				});//end fadeIn
			}); //end fadeOut
			return false;
		});//end bind
	};//end bindTagListItems
	bindTagListItems();
	
	$('#uncheck_all_tags').bind('click',function(){
		var listOfSelected = $('#item_selector li a.selected');
		listOfSelected.each(function(index){
			$(listOfSelected[index]).fadeOut(200,function(){
				$(listOfSelected[index]).removeClass('selected');
				$(listOfSelected[index]).fadeIn(200);
				$('#hiddenTagId').attr('value',"");
			});//end fadeOut
			
		});//end each
		return false;
	});//end bind
	//end tag selector
	
	
	
	
	var updateCategoryList = function(){
		$.getJSON('ajax/ajaxGetCategoryList.php',function(response){
			//unbind category list items
			$("#category_selector li a").unbind('click');
			
			//clear list
			$('#category_selector ul').empty();
			
			//regenerate list
			$('#category_selector ul').append("<li><a href='#' id='category_0'>None</a></li>");	
			$.each(response,function(index,value){
				$('#category_selector ul').append("<li><a href='#' id='category_"+ value +"'>"+index+"</a></li>\n");
			});//end each
			
			//rebind click handlers
			bindCatListItems();
		});//end json function
		
	};//end updateCategoryList
	
	
	
	
	var updateTagList = function(selected){
		$.getJSON('ajax/ajaxGetTagList.php',function(response){
			//unbind tag list items
			$('#item_selector li a').unbind('click');
			
			//clear list
			$('#item_selector ul').empty();
			
			//regenerate list	
			$.each(response,function(index,value){
				if(selected.indexOf("tag_"+value) > -1)
				{
					$('#item_selector ul').append("<li><a class='selected' href='#' id=\"tag_"+ value +"\">"+ index +"</a></li>\n");
				}else{
					$('#item_selector ul').append("<li><a href='#' id=\"tag_"+ value +"\">"+ index +"</a></li>\n");
				}//end if
			});//end each
			
			
			//rebind click handlers
			bindTagListItems();
		});//end json function
		
	};//end updateCategoryList
	
	
	
	
	
	//toggles animation/insertion of add form
	var toggleAddCat = function(){
		//add category form
		var addCatForm = $('#add_cat_form');
		
		if(addCatForm.height() > 0){
			//change button name to add
			$('#add_category_btn').html('Add');
			
			$('#add_cat_cancel_btn').unbind('click');
			addCatForm.animate({'height':'0'},'fast',function(){
				addCatForm.empty();
			});//end bind
		
		}else{
			//change button name close
			$('#add_category_btn').html('Close');
			
			//insert form
			addCatForm.append("<div class='edit_category_form'>" +
					"Add a Category | <a id='add_cat_cancel_btn' class='delete_category' href='#'>Cancel</a>"+
					"<form action='#' method='post'>"+
						"<p><input name='add_category' id='add_category'  type='text' /><input class='submit_button' type='submit' name='button' value='Add' /></p>"+
					"</form>"+
				"</div><!-- end edit_category_form -->");//end append
	
			addCatForm.animate({'height':'50px'},'fast');
			
			//add click functionality to cancel button
			$('#add_cat_cancel_btn').bind('click',function(){
				toggleAddCat();
				return false;
			});//end bind
			
			//add click functionality to the add category form button
			$('.edit_category_form form').bind('submit',function(){ 
				
				//ajax to add category to db
				if($('#add_category').attr('value') != ""){
					$.getJSON('ajax/ajaxAddCategory.php',{name:$('#add_category').attr('value')},function(response){
						
						if(response.error){
							$('#errors').empty().append('<ul>'+
															'<li>There was a problem creating a new category, please try again.</li>'+
														 '</ul>');
						}else{
							updateCategoryList();
							toggleAddCat();
							$("#current_category").fadeOut(300,function(){
								//strip out html tags
								var newName = response.name
								newName = newName.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
								
								$("#current_category").html(newName);
								$("#hiddenCategoryId").attr('value',response.id)
								
								$("#current_category").fadeIn(300);
							});//end fadeOut 
						}//end else
					});//end getJSON function
				}//end if

				return false;
			});//end bind
			
		};//end if
		
	};//end toggleAddCat
	
	//click event for add cat link
	$('#add_category_btn').bind('click',function(){
		
		toggleAddCat();
		
		return false;
	});//end bind
	//end add category form
	
	
	
	
	
	//toggles animation/insertion of add form
	var toggleAddTag = function(closeOnly){
		
		//add tag form
		var addTagForm = $('#add_tag_form');
		
		if(addTagForm.height() > 0){
			//change button text to add
			$('#add_tag_btn').html('Add');
			
			$('#add_tag_cancel_btn').unbind('click');
			addTagForm.animate({'height':'0'},'fast',function(){
				addTagForm.empty();
			});//end animate
		
		}else if(!closeOnly){
			//change button text to close
			$('#add_tag_btn').html('Close');
			
			addTagForm.append("<div class='edit_category_form tag_form'>" +
					"Add a Category | <a id='add_tag_cancel_btn' class='delete_category' href='#'>Cancel</a>"+
					"<form action='#' method='post'>"+
						"<p><input name='add_tag' id='add_tag'  type='text' /><input class='submit_button' type='submit' name='button' value='Add' /></p>"+
					"</form>"+
				"</div><!-- end edit_tag_form -->");//end append
	
			addTagForm.animate({'height':'50px'},'fast');
			
			//add click functionality to cancel button
			$('#add_tag_cancel_btn').bind('click',function(){
				toggleAddTag();
				return false;
			});//end bind
			
			//add click functionality to the add tag form button
			$('.edit_category_form.tag_form form').bind('submit',function(){ 
				
				//ajax to add tag to db
				if($('#add_tag').attr('value') != ""){
					$.getJSON('ajax/ajaxAddTag.php',{name:$('#add_tag').attr('value')},function(response){
						//if an error is returned from the ajax call
						if(response.error){
							$('#errors').empty().append('<ul>'+
															'<li>There was a problem creating a new tag, please try again.</li>'+
														 '</ul>');
						}else{

							//get selected tags and store the ids to an array which gets passed into the updateTagList() function
							var currentSelectedTags = $('#item_selector li a.selected');
							var currentSelectedTagsIds = [];
							currentSelectedTags.each(function(index){
								currentSelectedTagsIds.push($(currentSelectedTags[index]).attr('id'));
							});//end each
							
							//push in id of newly added tag to currentSelectedTagsIds array
							currentSelectedTagsIds.push("tag_"+response.id);
							
							
							//shows a confirmation msg than makes the msg disappear after 1 second
							addTagForm.fadeOut(200,function(){
								addTagForm.empty().append("<p id='tagAddSuccess'>Tag added successfully!</p>");
								addTagForm.fadeIn(100);
								toggleTagTimer = setInterval(function(){
									
									if(addTagForm.find('form').length == 0){
										toggleAddTag(true);
									};
									
									clearInterval(toggleTagTimer);
									
									//delay of 1 second
								},1000);//end toggleTagTimer
							});//end fadeOut
							
							
							//loop through items with the selected class, split off the tag part of the name and push only the number into an array
							var selectedTags = $('#item_selector li a.selected');
							var tagIdList = [response.id];
							selectedTags.each(function(index){
								var tagId = ($(selectedTags[index]).attr('id').split("_"))[1];
								tagIdList.push(tagId);
							});//end selectedTags
							
							//convert the array of tag ids into a string seperated by commas
							var tagListString = tagIdList.join(',');
							
							//send the comma seperated string of ids to the hidden field of the post form with id of hiddenTagId
							$('#hiddenTagId').attr('value',tagListString);
							
							//update the tag list, pass in an array of selected tag ids
							updateTagList(currentSelectedTagsIds);
						}//end if response.errors
					});//end getJSON function
				}//end if

				return false;
			});//end bind
			
		};//end if
		
	};//end toggleAddTag
	
	//click event for add tag link
	$('#add_tag_btn').bind('click',function(){
		
		toggleAddTag();
		
		return false;
	});//end bind
	
	//end add tag form
	
	
	
	
	//confirmMsg remove
	var confirmRemove = function(){
		confirmRemoveTimer = setInterval(function(){
			
			$('#confirmMsg').animate({'height':'0'},1000,function(){
				$('#confirmMsg').empty().hide();
			});
			clearInterval(confirmRemoveTimer);
		}, '5000');
		
	};
	confirmRemove();
	

	
	
	
});//end addPost_ajax.js file