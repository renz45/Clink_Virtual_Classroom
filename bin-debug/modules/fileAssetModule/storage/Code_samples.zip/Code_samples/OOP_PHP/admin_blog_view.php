<?php
require 'php/required.php';
session_start();
session_regenerate_id();

$_SESSION['userId'] = 1;

$postsPerPage = 8;
$pageToLoad = "admin_blog_view.php";

$header = new views_header();
$footer = new views_footer();
$adminViewPost = new views_AdminBlogViewPosts();

$blogModel = new model_blog();

//build header

$extraHeaderInfo = "
		<!-- <script type='text/javascript' src='js/viewPost_ajax.js'></script>-->";


$header->showAdminHeader($adminNavList, 'BLOG',$blogSubNavList,'View Post',views_header::BLOG_SUBNAV,$extraHeaderInfo);

//build col1 (left side with form and comments)
$errorList = array();
if(!empty($_GET['error'])){
	$errorList = explode(",",$_GET['error']);
}

//get the page number, if it doesnt exist in the url set the page to 1
if(empty($_GET['page']))
{
	$page = 1;
}else{
	$page = $_GET['page'];
}//end if

//get post info, total post count and the array of VO_post
$viewBy = "";

if(!empty($_GET['viewBy']) && $_GET['viewBy'] == "comments")
{
	//get post info and include comments, but only include new comments
	$postInfo = $blogModel->getPosts($page, $postsPerPage,NULL,NULL,NULL,true,true,true);
	$viewBy = $_GET['viewBy'];
}else{
	//get post info but don't include comments
	$postInfo = $blogModel->getPosts($page, $postsPerPage,NULL,NULL,NULL,false,true,true);
}

//pass array of VO_post to $postList
$postList = $postInfo['postList'];

//calculate total pages
$totalPages = ceil($postInfo['count'] / $postsPerPage);


$adminViewPost->showCol1($postList, $errorList,$totalPages,$page,$pageToLoad,$_GET,$viewBy);



	
//build col2 (right side with category and tag selectors)
$categoryList = $blogModel->getCategories();
$tagList = $blogModel->getTags();
$adminViewPost->showCol2($categoryList,$tagList);


//build footer
$footer->showFooter();

//disconnect $blogModel from mySql
$blogModel->disconnect();