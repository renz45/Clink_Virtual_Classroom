<?php
class views_pagination
{
	
	private $_totalPages;
	private $_page;
	private $_pageToLoad;
	private $_GETVars;
	
	/**
	 * 
	 * Generates pagination, can be used for any element needing pagination
	 * @param int(required) $totalPages - total pages of items being paginated
	 * @param int(required) $page - current page
	 * @param string(required) $pageToLoad - url of the page which the pagination is being used on
	 * @param array(optional) $GETVars - array of $_GET vars to be preserved.
	 */
	public function __construct($totalPages,$page,$pageToLoad,$GETVars = array())
	{
		$this->_page = $page;
		$this->_pageToLoad = $pageToLoad;
		$this->_totalPages = $totalPages;
		$this->_GETVars = $GETVars;
	}
	
	public function showPagination()
	{
		//get the base url plus the existing variables, but strip away the page var, page is added in the anchor tags
		$url = $this->preserveURL($this->_pageToLoad, $this->_GETVars);
		
		
		echo "<p class='pagination'>";
		echo		"<span class='p_next'>";
					//if the page isnt the last page of items than give the option to go to next or last pages
					if($this->_page > 1)
					{
		echo			"<a href=\"". $url ."page=1\">&lt;&lt; First</a>";
		echo			" | "; 
		echo			"<a href=\"". $url ."page=". ($this->_page-1) ."\">&lt; Next</a>";
					}//end if
		echo		"</span>";
		echo	 	"$this->_page of $this->_totalPages";
		echo		"<span class='p_prev'>";
				 	//if the current page isnt the first page give the option to go previous or last
				 	if($this->_page < $this->_totalPages)
				 	{
		echo	 		"<a href=\"". $url ."page=". ($this->_page+1) ."\">Prev &gt;</a>";
		echo	 		" | ";  
		echo	 		"<a href=\"".$url."page=". $this->_totalPages ."\">Last &gt;&gt;</a>";
				 	}//end if
		echo	 	"</span>";
		echo"</p>\n";
	}//end init
	
	private function preserveURL($pageToLoad, $GETVars)
	{
		$newURL = $pageToLoad."?";
		//strip out page variable and reconstruct the url as a string
		$index = 0;
		foreach ($GETVars as $var=>$value)
		{
			//we will reinsert the page var in the link url
			if($var != "page")
			{
				$newURL .= $var."=".$value;
				$newURL .= "&";
			}
			
			$index++;
		}//end for each
		return $newURL;
	}//end preserveURL
	
}