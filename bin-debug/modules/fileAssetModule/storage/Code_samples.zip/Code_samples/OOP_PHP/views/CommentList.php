<?php
class views_CommentList
{
	public function __construct()
	{
		
	}//end constuct
}//end class