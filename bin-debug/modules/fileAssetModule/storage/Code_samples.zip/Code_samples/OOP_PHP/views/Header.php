<?php
/**
 * 
 * Outputs html for headers for both admin and user pages.
 * 
 * Contains constants for admin sub nav positioning BLOG_SUBNAV - admin blog sub nav, OFFERINGS_SUBNAV - admin offerings sub nav.
 * @author adamrensel
 *
 */
class views_header
{
	//constants defining a class for the subnav div that control horizontal positioning
	const BLOG_SUBNAV =	"admin_blog_sub_nav";
	const OFFERINGS_SUBNAV = "admin_offerings_sub_nav";
		
	public function __construct()
 	{

	}
	
	/**
	 * 
	 * displays user page header.
	 * @param array(required) $navList - assoc array of page names and page links ex. ['BLOG'=>'blog.php','ABOUT'=>'about.php']
	 * @param string(required) $page - string which sets which nav link is active ex. 'BLOG'
	 * @param boolean(false) $banner - boolean that toggles the large banner picture on and off
	 * @param boolean(false) $isLoggedIn - boolean, sets logged in state to display logged in util menu
	 */
	public function showUserHeader($navList,$page,$banner = false, $isLoggedIn = false)
	{
		
echo "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
		'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
		
		<html xmlns='http://www.w3.org/1999/xhtml'>
			<head>
				<title>Intentional Health</title>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
				<link rel='shortcut icon' href='img/logo_favicon.ico' type='image/x-icon' />
				<!-- <meta name='Keywords' content='keywords go here seperated by comas' />
				<meta name='Description' content='description here' /> -->
		
				
				<link rel='stylesheet' type='text/css' href='css/main.css' />
				
				<!--[if IE 7]>
					<link rel='stylesheet' type='text/css' href='css/ie7.css' />
				<![endif]-->
		
			</head>
			
			<body>
				<div id='fixed_head'>
					<div id='header'>
						<div id='header_wrapper'>
							<h1><a href='index.php'>Intentional Health Products</a></h1>\n";
		//builds logged in menu so the user can switch between admin and user sections, as well as log out
		if ($isLoggedIn == true){
			echo				"\t\t\t\t\t<p id='login_menu'>
								<a href='#'>Home</a> | 
								<a href='#'>Log Out</a>
							</p>\n";
		}//end if
		
		echo	 "\t\t\t\t\t<ul id='nav'>\n";
		
		//generates the navigation menu and active link
		foreach ($navList as $name=>$link){
			if ($name == $page){
				echo "\t\t\t\t\t\t<li><a class='active' href=\"$link\">$name</a></li>\n";	
			}else{
				echo "\t\t\t\t\t\t<li><a href=\"$link\">$name</a></li>\n";
			}//end if
		}//end foreach
		
		echo	 "\t\t\t\t\t</ul>	
						</div><!-- end header_wrapper -->
					</div><!-- end header -->
					<div id='sub_nav'>
						<ul>
							<li><a href='contact.php'>Contact</a></li>
						</ul>
					</div>
				</div><!-- end fixed_head -->
				
				<p id='nav_bottom'></p>
				
				<div id='wrapper'>\n";
		
		//adds banner in if $banner = true
		if ($banner == true){			
			echo		"\t\t\t<h2 id='banner'>Helping you help yourself naturally.</h2>\n";		
		}//end if		
							
		echo		"\t\t\t<div id='content'>\n";
	}//end showUserHeader
	
	
	
	
	/**
	 * 
	 * Outputs html for admin page header.
	 * use constants BLOG_SUBNAV and OFFERINGS_SUBNAV for existing blog and offerings sub nav
	 * 
	 * @param array(required) $navList - assoc array of page names and page links ex. ['BLOG'=>'blog.php','ABOUT'=>'about.php']
	 * @param string(required) $page -  string which sets which nav link is active ex. 'BLOG'
	 * @param array(NULL) $subNav - assoc array of sub nav names and page links ex. ['Add Posts'=>'blog_addPost.php','View Posts'=>'blog_view_posts.php']
	 * @param string(NULL) $subPage - string which sets which sub nav link is active ex. 'Add Posts'
	 * @param string(NULL) $subNavClass - string which sets a class to the subNav div which determines positioning
	 * 
	 */
	public function showAdminHeader($navList,$page,$subNav = NULL,$subPage = NULL, $subNavClass = NULL,$extraHeaderInfo = NULL)
	{
	
 echo	"<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
		'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
		
		<html xmlns='http://www.w3.org/1999/xhtml'>
			<head>
				<title>Intentional Health</title>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
				<link rel='shortcut icon' href='img/logo_favicon.ico' type='image/x-icon' />
				<!-- <meta name='Keywords' content='keywords go here seperated by comas' />
				<meta name='Description' content='description here' /> -->
		
				
				<link rel='stylesheet' type='text/css' href='css/main.css' />
				<link rel='stylesheet' type='text/css' href='css/admin.css' />
				
				
				<!--[if IE 7]>
					<link rel='stylesheet' type='text/css' href='css/ie7.css' />
				<![endif]-->\n";
				
 			if(!is_null($extraHeaderInfo)){
 				echo $extraHeaderInfo;
 			}
				
				
				
				
	echo	"\t\t\t</head>
			
			<body>
				<div id='fixed_head'>
					<div id='header'>
						<div id='header_wrapper'>
							<h1><a href='#'>Intentional Health Products</a></h1>
							<p id='login_menu'>
								<a href='#'>Home</a> | 
								<a href='#'>Log Out</a>
							</p>
							<ul id='nav'>\n";
 
//builds main nav list
foreach ($navList as $name=>$link){
	if ($page == $name){
		echo "\t\t\t\t\t\t\t\t<li><a class='active' href=\"$link\">$name</a></li>\n";
	}else{
		echo "\t\t\t\t\t\t\t\t<li><a href=\"$link\">$name</a></li>\n";
	}//end if
}//end foreach
echo			"\t\t\t\t\t\t\t</ul>	
						</div><!-- end header_wrapper -->
					</div><!-- end header -->\n";

//adds a class to the sub nav for positioning purposes		
echo "\t\t\t\t<div id='sub_nav' class=\"$subNavClass\">\n";

					
	echo			"\t\t\t\t\t<ul>\n";

//builds subnav items if they exist
if (isset($subNav)){
	$count = 0;
	foreach ($subNav as $subName=>$link) {
		$classes = "";
		$classes .= (($subName == $subPage)?'active ':'');
		$classes .= (($count == 0)?'right_side ':'');
		$classes .= (($count == count($subNav)-1)?'left_side ':'');
		
		echo "\t\t\t\t\t\t<li><a class=\"$classes\" href=\"$link\">$subName</a></li>\n";
		
		$count++;
	}//end forach
}//end if
							
echo       	   "\t\t\t\t\t</ul>
				</div>
					
					</div><!-- end fixed_head -->
				
				<p id='nav_bottom'></p>
				
			
				
				<div id='wrapper'>		
					
					
								
					<div id='content'>\n"; 
	}//end showAdminHeader
}//end class