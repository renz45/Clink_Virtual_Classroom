<?php
class views_AdminBlogViewPosts
{
	public function __construct() {
		
	}
	
	public function showCol1($postList,$errorList,$totalPages,$page,$pageToLoad,$GETVars,$viewBy = "")
	{
		$pagination = new views_pagination($totalPages, $page, $pageToLoad, $GETVars);
		
		//error block
		echo "\t\t\t\t<div id='col1'>
					<div id='errors'>\n";
						if(!empty($errorList)){
							echo "\t\t\t\t\t\t<ul>\n";
							
							foreach ($errorList as $error){
								$errorMsg = "";
								switch($error){
									case 'post':
										$errorMsg = 'There was a problem submiting the post, please try again';
									break;
									case 'title':
										$errorMsg = 'A title is required to make a post, please add a title.';
									break;
									case 'content':
										$errorMsg = 'Content is required to make a post, please add content.';
									break;
								}//end switch
								echo "\t\t\t\t\t\t\t<li>$errorMsg</li>\n";
							}//end foreach
							
							echo "\t\t\t\t\t\t</ul>\n";
						}
		echo "\t\t\t\t\t</div><!-- end errors -->\n";
		//end error block

		//post block
		echo "\t\t\t\t\t<p id='admin_post_state'>View by: <a class='". ($viewBy!="comments"?'active':'') ."' href='admin_blog_view.php?viewBy=date'>New Posts</a> &nbsp;|&nbsp; <a class='". ($viewBy=="comments"?'active':'') ."' href='admin_blog_view.php?viewBy=comments'>New Comments</a></p>\n";

		//TODO sort by flag
		//echo "\t\t\t\t\t<p id='sort_pointer'>Sorted by Category: <a href='#'>Category1</a> , Tag: All Posts again <span><a href='admin.php'>Show All Posts</a></span></p>\n";
					
		echo "\t\t\t\t\t<ul id='admin_post_list'>\n";
					if(isset($postList) && count($postList)>0){	
						foreach ($postList as $post){
							$postDate = date('l M jS, o \a\t g:i a',strtotime($post->datePosted));
							
							if($post->numNewComments > 0){
								echo "\t\t\t\t\t\t<li class='has_comments'>
									<p class='post_btn_group'><a class='edit_post_btn' title='Edit Post' href='admin_blog_add.php?editPost=$post->id'>Edit post</a><a class='delete_post' title='delete post' href='#'>Delete Post</a><a title='Mark all comments read' class=' mark_all_read' href='#'>Mark All Comments as Read</a></p>
									<a title='Open new comments' class='large_post_button' href='#'><span class='title'>$post->title</span> Posted by <span class='author'>$post->userName</span> on <br />$postDate</a><span class='new_comments' title='New comments'>$post->numNewComments</span>
								</li>\n";
								
								echo "\t\t\t\t\t\t<li class='admin_comment'>
							<ul class='comment_list'>\n";
								foreach ($post->commentList as $comment){
									$commentDate = date('l M jS, o \a\t g:i a',strtotime($comment->datePosted));
									
									echo "\t\t\t\t\t\t\t\t<li>
											<p class='comment_top'><span class='comment_date'>$commentDate</span> <span class='comment_reply_link'><a href='#'>Reply</a> | <a href='#'>Edit</a></span></p>
										
											<p class='comment_name'><span>$comment->author</span> says:</p>
											<p class='comment_content'>$comment->content</p>
											<p class='comment_site'><a href='http://$comment->website'>$comment->website</a></p><a class='mark_read' href='#' title='
											Mark as read'>Mark as read</a>
										</li><!-- end comment -->";
								}//end foreach
								echo "\t\t\t\t\t\t\t</ul>
							</li>";
								
							//end if(count($post->numNewComments)
							}else{
								echo	"\t\t\t\t\t\t<li>
									<p class='post_btn_group'><a class='edit_post_btn' title='Edit Post' href='admin_blog_add.php?editPost=$post->id'>Edit post</a><a class='delete_post' title='delete post' href='#'>Delete Post</a></p>
									<span class='large_post_button'><span class='title'>$post->title</span> Posted by <span class='author'>$post->userName</span> on <br />$postDate</span>
								</li>\n";
							}//end else for if(count($post->numNewComments)
						}//end foreach
					}else{
						echo "\t\t\t\t\t\t<li><h2>There are no posts for this selection.</h2></li>";
					}//end else
					
					
		echo "\t\t\t\t</ul><!-- end admin_post_list -->\n";
		
		$pagination->showPagination();
		
		//end post block
		
		echo	"\t\t\t\t\t</div><!-- end col1 -->\n";
	}//end showCol1
	
	public function showCol2($categoryList,$tagList)
	{
		echo "\t\t\t\t<div id='col2'>
					
					<div id='add_post_category'>
						<h3>Categories <a id='add_category_btn' href='#'>Add</a></h3>
						
						<div id='add_cat_form'>
						
						</div>
						
						<div id='category_selector' class='list_drop_down'>
							<p><a id='current_category' href='#'>Choose a category</a></p>
							<ul>
								<li><a href='#' id='category_0'>None</a></li>\n";
		foreach ($categoryList as $cat=>$id){
			echo "\t\t\t\t\t\t\t\t<li><a href='#' id=\"category_$id\">$cat</a></li>\n";
		}//end foreach
		echo  "\t\t\t\t\t\t\t</ul>
						</div><!-- category_drop_down -->
					</div><!-- add_post_category -->
					
					<div id='add_post_tag'>
						<h3>Choose tags <a id='add_tag_btn' href='#'>Add</a></h3>
						
						<div id='add_tag_form'>
						
						</div>
						
						<div id='item_selector'>
							<ul>\n";
		
		foreach ($tagList as $tag=>$id){
			echo "\t\t\t\t\t\t\t\t<li><a href='#' id=\"tag_$id\">$tag</a></li>\n";
		}//end forach
		
		echo "\t\t\t\t\t\t\t</ul>
						</div><!-- end item_selector -->
						<a id='uncheck_all_tags' href='#'>Uncheck All</a>
					</div><!-- end add_post_tag -->
											
				</div><!-- end col2 -->\n";
	}//end showCol2

	public function showAddImgModal(){
		echo "\t\t<p><a style='visibility:hidden;' href=\"#\" id=\"dialog_link\"></a></p>

		<!-- ui-dialog -->
		<div id=\"dialog\" title=\"Choose a Picture\">
			<div id=\"dialogForms\">
				<form id=\"imageUploadForm\" action=\"js/jquery_rte_modified/imageUpload/imageUpload.php\" method=\"post\" name=\"f\" enctype=\"multipart/form-data\" target=\"theFrame\"  onsubmit=\"document.getElementById('frame').src='js/jquery_rte_modified/imageUpload/imageUpload.php';\">
					<p><label for=\"imageUploadFile\">Upload a new image:</label><br/>
					
						<input id=\"imageUploadFile\" type=\"file\" name=\"file\" />
						<input id=\"imageUploadSubmit\" type=\"submit\" value=\"submit\" />
					</p>
				</form>
				
				<form id=\"imageUploadList\">
					<p>
						<label for=\"imageList\">or choose from the list:</label>
						<select name=\"imageList\" id=\"imageList\">
							<!-- image list <opion></option> -->
						</select>
					</p>
				</form>
				<p>
					Selected Image: <br />
					<img alt=\"preview\" id=\"imageUploadPreview\" src=\"\">
				</p>	
			</div> <!-- end dialogForms -->
			
			<IFRAME id=\"frame\" style=\"border:none;\"  name=\"theFrame\" width=\"100%\" height =\"0\" ></IFRAME>
			
		</div><!-- end dialog -->\n";
	}
}