<?php
class views_AdminBlogAddPost 
{
	public function __construct() {
		
	}
	
	/**
	 * 
	 * View for the admin_blog_add.php, col1
	 * @param int(required) $userId - current userId who is logged in, most likely comes from session, used to add an authorId to new posts
	 * @param array(optional) $errorList - list of errors to be displayed
	 * @param boolean(optional) $postAdded - boolean value, used to display confirmation msg for a successful post
	 * @param VO_post(optional) $postVO - instance of the post vo, which contains information needed to display and edit a post
	 */
	public function showCol1($userId,$errorList=NULL,$postAdded=false,$postVO = NULL)
	{
		$title = "";
		$content = "";
		$post_id = "";
		$tagList = "";
		$categoryId = "";
		
		print_r($postVO);
		
		if(!is_null($postVO) && !is_a($postVO, 'VO_post')){
			//throw error if the $postVO is not the post value object
			throw new Exception("[$postVO] must be an instance of VO_post");	
		}elseif (!is_null($postVO) && is_a($postVO, 'VO_post')){
			$title = $postVO->title;
			$content = $postVO->content;
			$post_id = $postVO->id;
			$tagList = implode(",",$postVO->tagList);
			$categoryId = $postVO->categoryId;
		}
		echo "\t\t\t\t<div id='col1'>
					<div id='errors'>\n";
						if(!empty($errorList)){
							echo "\t\t\t\t\t\t<ul>\n";
							
							foreach ($errorList as $error){
								$errorMsg = "";
								switch($error){
									case 'post':
										$errorMsg = 'There was a problem submiting the post, please try again';
									break;
									case 'title':
										$errorMsg = 'A title is required to make a post, please add a title.';
									break;
									case 'content':
										$errorMsg = 'Content is required to make a post, please add content.';
									break;
								}//end switch
								echo "\t\t\t\t\t\t\t<li>$errorMsg</li>\n";
							}//end foreach
							
							echo "\t\t\t\t\t\t</ul>\n";
						}
		echo "\t\t\t\t\t</div><!-- end errors -->\n";
		if($postAdded){
			echo "\t\t\t\t<div id='confirmMsg'>
								<p>Post was made successfully!</p>
						  </div>\n";
		}//end if
		echo "\t\t\t\t\t<form id='add_post_form' method='post' action='php/formActions/modifyPost.php'>
						<p>
							<label for='form_title'>Title:</label><br />
							<input id='form_title' type='text' name='title' value=\"$title\" />
						</p>
						
						<p>
							<label for='form_content'>Content:</label><br />
							<textarea class='textEditor' id='form_content' name='content' cols='55' rows='12'>$content</textarea>
							<input type='hidden' id='hiddenCategoryId' name='category_id' value='$categoryId'/>
							<input type='hidden' id='hiddenTagId' name='tag_id' value='$tagList'/>
							<input type='hidden' name='user_id' value=\"$userId\" />
						</p>	
																					
						<p><input class='submit_button' type='submit' name='button' value='". ((isset($postVO))?'Edit Post':'Add Post') ."' /></p>
					</form><!-- end add_post_form -->\n";
		//this and the above line might need '&& empty($postVO->id)'
		
		if(isset($postVO)){								
			echo "\t\t\t\t\t<div id='comment_block'>
							<h3>Comments</h3>
							<ul class='comment_list'>
								<li>
									<p><span class='comment_date'>January 1,2010 at 12:47pm</span></p>
								
									<div class='admin_comment_reply'>
										<form method='post' action='#'>
											
											<p>
												<label for='form_name'>Name: </label><br />
												<input id='form_name' type='text' name='name' value='Adam Rensel' />
											</p>
											
											<p>
												<label for='form_email'>Email: </label><br />
												<input id='form_email' type='text' name='email' value='' />
											</p>
											
											<p>
												<label for='form_website'>Website: </label><br />
												<input id='form_website' type='text' name='website' value='www.adamrensel.com' />
											</p>
											
											<p>
												<label for='comment'>Comment:</label><br />
												<textarea name='comment' rows='7' cols='56'>Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala </textarea>
											</p>
											<p><input class='submit_button' type='submit' name='button' value='Edit' /><a class='submit_button' href='#'>Cancel</a></p>
										</form>
									</div><!-- end admin_comment_reply -->
									
								</li>
								
								<li class='reply'>
									<p><span class='comment_date'>January 1,2010 at 12:47pm</span> <span class='comment_reply_link'><a href='#'>Reply</a> | <a href='#'>Edit</a></span></p>
									<p class='comment_name'><span>Christa</span> says in response to Adam Rensel:</p>
									<p class='comment_content'> Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala </p>
								
								</li>
								
								<li class='admin_reply'>
									<p><span class='comment_date'>January 1,2010 at 12:47pm</span> <span class='comment_reply_link'><a href='#'>Reply</a> | <a href='#'>Edit</a></span></p>
									<p class='comment_name'><img src='images/avatar.jpg' alt='avatar.jpg' width='50' height='50' /><span> Carla</span> says in response to Adam Rensel:</p>
									<p class='comment_content'> Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala </p>
									
									<div class='admin_comment_reply'>
										<form method='post' action='#'>
											<p>
												<label for='comment'>Comment</label><br />
												<textarea name='comment' rows='7' cols='56'></textarea>
											</p>
											<p><input class='submit_button' type='submit' name='button' value='Submit' /><a class='submit_button' href='#'>Cancel</a></p>
										</form>
									</div><!-- end admin_comment_reply -->
									
								</li>
								
								<li class='admin_comment'>
									<p><span class='comment_date'>January 1,2010 at 12:47pm</span><span class='comment_reply_link'><a href='#'>Reply</a> | <a href='#'>Edit</a></span></p>
									<p class='comment_name'><img src='images/avatar.jpg' alt='avatar.jpg' width='50' height='50' /><span> Carla</span> says:</p>
									<p class='comment_content'> Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala Here is my comment to this post someday in the future trala </p>
								
								</li>
							</ul>
							
							<p class='pagination'><span class='p_next'><a href='#'>&lt;&lt; First</a> | <a href='#'>&lt; Next</a></span> 1 of 2 <span class='p_prev'><a href='#'>Prev &gt;</a> | <a href='#'>Last &gt;&gt;</a></span></p>
							
						</div><!-- end comment_block -->\n";
		}//end if(isset($postVO))						
		echo	"\t\t\t\t\t</div><!-- end col1 -->\n";
	}//end showCol1
	
	/**
	 * 
	 * View for the admin_blog_add.php, col2
	 * @param array(required) $categoryList - list of categories in an assoc array catName => catId, catName => catId
	 * @param array(required) $tagList - list of tags in an assoc array tagName => tagId, tagName => tagId 
	 */
	public function showCol2($categoryList,$tagList)
	{
		echo "\t\t\t\t<div id='col2'>
					
					<div id='add_post_category'>
						<h3>Categories <a id='add_category_btn' href='#'>Add</a></h3>
						
						<div id='add_cat_form'>
						
						</div>
						
						<div id='category_selector' class='list_drop_down'>
							<p><a id='current_category' href='#'>Choose a category</a></p>
							<ul>
								<li><a href='#' id='category_0'>None</a></li>\n";
		foreach ($categoryList as $cat=>$id){
			echo "\t\t\t\t\t\t\t\t<li><a href='#' id=\"category_$id\">$cat</a></li>\n";
		}//end foreach
		echo  "\t\t\t\t\t\t\t</ul>
						</div><!-- category_drop_down -->
					</div><!-- add_post_category -->
					
					<div id='add_post_tag'>
						<h3>Choose tags <a id='add_tag_btn' href='#'>Add</a></h3>
						
						<div id='add_tag_form'>
						
						</div>
						
						<div id='item_selector'>
							<ul>\n";
		
		foreach ($tagList as $tag=>$id){
			echo "\t\t\t\t\t\t\t\t<li><a href='#' id=\"tag_$id\">$tag</a></li>\n";
		}//end forach
		
		echo "\t\t\t\t\t\t\t</ul>
						</div><!-- end item_selector -->
						<a id='uncheck_all_tags' href='#'>Uncheck All</a>
					</div><!-- end add_post_tag -->
											
				</div><!-- end col2 -->\n";
	}//end showCol2

	/**
	 * 
	 * html for the image add modal (sort of hacky, it was an experiment trying to get two existing componants to work together)
	 */
	public function showAddImgModal(){
		echo "\t\t<p><a style='visibility:hidden;' href=\"#\" id=\"dialog_link\"></a></p>

		<!-- ui-dialog -->
		<div id=\"dialog\" title=\"Choose a Picture\">
			<div id=\"dialogForms\">
				<form id=\"imageUploadForm\" action=\"js/jquery_rte_modified/imageUpload/imageUpload.php\" method=\"post\" name=\"f\" enctype=\"multipart/form-data\" target=\"theFrame\"  onsubmit=\"document.getElementById('frame').src='js/jquery_rte_modified/imageUpload/imageUpload.php';\">
					<p><label for=\"imageUploadFile\">Upload a new image:</label><br/>
					
						<input id=\"imageUploadFile\" type=\"file\" name=\"file\" />
						<input id=\"imageUploadSubmit\" type=\"submit\" value=\"submit\" />
					</p>
				</form>
				
				<form id=\"imageUploadList\">
					<p>
						<label for=\"imageList\">or choose from the list:</label>
						<select name=\"imageList\" id=\"imageList\">
							<!-- image list <opion></option> -->
						</select>
					</p>
				</form>
				<p>
					Selected Image: <br />
					<img alt=\"preview\" id=\"imageUploadPreview\" src=\"\">
				</p>	
			</div> <!-- end dialogForms -->
			
			<IFRAME id=\"frame\" style=\"border:none;\"  name=\"theFrame\" width=\"100%\" height =\"0\" ></IFRAME>
			
		</div><!-- end dialog -->\n";
	}
}