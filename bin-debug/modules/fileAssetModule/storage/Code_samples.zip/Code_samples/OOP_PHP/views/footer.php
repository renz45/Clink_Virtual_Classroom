<?php

class views_footer
{
	public function __construct() 
	{
		
	}
	
	public function showFooter()
	{
		echo		"</div><!-- end content -->
		
				</div><!-- end wrapper -->
				
				<div id='footer'>
					<h1><a href='#'> Intentional Health Products</a></h1>
					<div id='footer_text'>
						<ul>
							<li>Intentional Health Products, LLC &copy; 2010 Carla Roethlisberger</li>
							<li> | </li>
							<li><a href='#'>Site Map</a></li>
							<li> | </li>
							<li><a href='contact.php'>Contact</a></li>
							<li> | </li>
							<li><a href='privacy.php'>Privacy Policy</a></li>
							<li> | </li>
							<li><a href='#'>Admin Log In</a></li>
						</ul>
						
						<p>Development by <a href='#'>Adam Rensel</a> </p>
					</div><!-- end footer_text -->
				</div><!-- end footer -->
			</body>
		</html>";
	}//end showFooter
}//end class