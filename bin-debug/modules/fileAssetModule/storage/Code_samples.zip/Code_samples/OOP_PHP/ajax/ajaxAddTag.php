<?php
set_include_path($_SERVER['DOCUMENT_ROOT']);
require_once 'php/initClasses.php';

//test to make sure there is a name value in the $_GET global
if(empty($_GET['name']))
{
	//send error if name doesnt exist in GET
	$jsonReturn = array('error'=>'No information sent, please send category a name');
}else{
	//instantiate model and run addTag method
	$blog = new model_blog();
	try {
		$jsonReturn = $blog->addTag($_GET['name']);
	}catch (Exception $e){
		$jsonReturn = array('error'=>$e->getMessage());
	}
	
}

echo json_encode($jsonReturn);