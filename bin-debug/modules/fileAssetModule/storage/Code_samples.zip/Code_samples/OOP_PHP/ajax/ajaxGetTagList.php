<?php
set_include_path($_SERVER['DOCUMENT_ROOT']);
include 'php/initClasses.php';

$blog = new model_blog();
try{
	$jsonReturn = $blog->getTags();
}catch(exception $e){
	$jsonReturn = array('error'=>$e->getMessage());
}

echo json_encode($jsonReturn);