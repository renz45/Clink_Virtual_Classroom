<?php
set_include_path($_SERVER['DOCUMENT_ROOT']."/ih_test/");
require_once 'php/initClasses.php';

//test if there is a name in GET global
if(empty($_GET['name']))
{
	//return error msg if the name isnt found in GET global
	$jsonReturn = array('error'=>'No information sent, please send category a name');
}else{
	//instantiate model and run addCategory method
	$blog = new model_blog();
	try {
		$jsonReturn = $blog->addCategory($_GET['name']);
	}catch (Exception $e){
		$jsonReturn = array('error'=>$e->getMessage());
	}
}//end else

echo json_encode($jsonReturn);