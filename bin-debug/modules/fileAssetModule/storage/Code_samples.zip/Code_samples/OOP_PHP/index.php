<?php
require_once 'php/initClasses.php';


$header = new views_header();
$footer = new views_footer();


/* $navList = array('BLOG'=>'index.php',
			 	   'ABOUT'=>'about.php',
				   'PRODUCTS'=>'products.php',
				   'SERVICES'=>'services.php');

$subNavList = array('NEWER Post'=>'admin_addPost.php',
				    'Add Post'=>'admin_viewPost.php');

$header->showUserHeader($navList, 'BLOG', true, false);

$footer->showFooter(); */
?>
