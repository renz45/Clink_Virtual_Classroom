<?php
//TODO modify the get comments to return the array of comments as well as a total count for pagination
//TODO modify get categories and get tags to return total counts for totals in parentheses on the side bar.
//TODO editPost method needs to be created blog model
//TODO markAsRead method needs to be created in blog model
//TODO markAllAsRead method needs to be created in blog model
//TODO deletePost method needs to be created in blog model
//TODO addComment method needs to be created in blog model
//TODO editComment method needs to be created in blog model
require 'php/required.php';
session_start();
session_regenerate_id();

$_SESSION['userId'] = 1;

$header = new views_header();
$footer = new views_footer();
$adminAddPost = new views_AdminBlogAddPost();

$blogModel = new model_blog();


//build header

$extraHeaderInfo = "
		<link rel='stylesheet' type='text/css' href='js/jquery_rte_modified/jquery.rte.css' />
		<link type='text/css' href='css/custom-theme/jquery-ui-1.8.6.custom.css' rel='stylesheet' />
		<script type='text/javascript' src='js/jquery-1.4.3.min.js'></script>
		<script type='text/javascript' src='js/jquery_rte_modified/jquery.rte.tb.js'></script>
		<script type='text/javascript' src='js/jquery_rte_modified/jquery.rte.js'></script>
		<script type='text/javascript' src='js/textEditor.js'></script>
		<script type='text/javascript' src='js/addPost_ajax.js'></script>

		<!-- for the image upload -->
		<link type='text/css' href='js/jquery_rte_modified/imageUpload/css/custom-theme/jquery-ui-1.8.6.custom.css'' rel='stylesheet' />
		<script type='text/javascript' src='js/jquery_rte_modified/imageUpload/js/jquery-ui-1.8.6.custom.min.js'></script>
		<link type='text/css' href='js/jquery_rte_modified/imageUpload/css/jquery.Jcrop.css' rel='stylesheet' />
		<link type='text/css' href='js/jquery_rte_modified/imageUpload/css/imageUpload.css' rel='stylesheet' />
		<script type='text/javascript' src='js/jquery_rte_modified/imageUpload/js/jquery.Jcrop.min.js'></script>
		<script type='text/javascript' src='js/jquery_rte_modified/imageUpload/js/imageUploadOuter.js'></script>
		<!-- end imageupload -->";


$header->showAdminHeader($adminNavList, 'BLOG',$blogSubNavList,'Add Post',views_header::BLOG_SUBNAV,$extraHeaderInfo);

//build col1 (left side with form and comments)
//pass in error list
$errorList = array();
if(!empty($_GET['error'])){
	$errorList = explode(",",$_GET['error']);
}
//this saves the post if there is an error and the page has to be reloaded
$post = NULL;
if(isset($_SESSION['savedPost']) && !is_null($_SESSION['savedPost'])){
	$post = $_SESSION['savedPost'];
	$_SESSION['savedPost'] = NULL;
}
//sets the post added var which toggles a confirmation panel
$postAdded = false;
if(isset($_GET['postAdded'])){
	$postAdded = true;
}

//if the editPost get var is set
if(isset($_GET['editPost'])){
	$postInfo = $blogModel->getPosts(1, 1,$_GET['editPost'],NULL,NULL,false,true,false);
	$post = $postInfo['postList'][0];
}

$adminAddPost->showCol1($_SESSION['userId'], $errorList,$postAdded,$post);

//build col2 (right side with category and tag selectors)
$categoryList = $blogModel->getCategories();
$tagList = $blogModel->getTags();
$adminAddPost->showCol2($categoryList,$tagList);

$adminAddPost->showAddImgModal();

//build footer
$footer->showFooter();
