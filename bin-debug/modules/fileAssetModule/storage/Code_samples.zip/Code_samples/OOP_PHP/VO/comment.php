<?php
/**
 * 
 * comment value object contains properties as arguments in the constructor as well as getters/setters for each.  ex $vo_post->title = "hello world" or echo $vo_post->title
 * values:id(int), author(string), content(string), email(string), website(string), notifyAuthor(boolean), datePosted(string), replyToCommentId(int)
 * 
 * 
 * @author adamrensel
 *
 */
class VO_comment
{
	private $id;
	private $author;
	private $content;
	private $email;
	private $website;
	private $notifyAuthor;
	private $datePosted;
	private $replyToCommentId;
	private $replyList = array();
	
	public function __construct($_id=NULL, $_author=NULL, $_content=NULL, $_email=NULL, $_website=NULL, $_notifyAuthor=NULL, $_datePosted=NULL, $_replyToCommentId=NULL)
	{
		$this->id = $_id;
		$this->author = $_author;
		$this->content = $_content;
		$this->email = $_email;
		$this->website = $_website;
		$this->notifyAuthor = $_notifyAuthor;
		$this->datePosted = $_datePosted;
		$this->replyToCommentId = $_replyToCommentId;
	}//end construct
	
	//getter
	public function __get($key)
	{
		return $this->$key;
	}//end __get()
	
	//setter
	public function __set($property,$value)
	{
		//checks to make sure the property is is in this class
		if(!property_exists($this, $property))
		{
			throw new Exception($property .' property does not exist in this class');
		}
				
		//check for data types
		switch ($property){
			//these are string values
			case "author":
			case "content":
			case "email":
			case "datePosted":
			case "website":
				if(!is_string($value) && !is_null($value)){
					throw new Exception("The $property property requires a string, the value $value is not a string ");
				}
			break;
			//these are int values
			case "id":
			case "replyToCommentId":
				if(!is_int($value) && !is_null($value)){
					throw new Exception("The $property property requires an int, the value $value is not an int ");
				}
			break;
			//these are boolean values
			case "notifyAuthor":
				if(!is_bool($value) && !is_null($value)){
					throw new Exception("The $property property requires a boolean, the value $value is not a boolean ");
				}
			break;
			//these are array values
			case "replyList":
				if(!is_array($value) && !is_null($value)){
					throw new Exception("The $property property requires an array, the value $value is not an array ");
				}
			break;
		}//end switch
				
		$this->$property = $value;
		
	}//end __set()
	
}//end class

