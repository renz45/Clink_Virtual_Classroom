<?php
/**
 * 
 * Blog post value object contains properties as arguments in the constructor as well as getters/setters for each.  ex $vo_post->title = "hello world" or echo $vo_post->title
 * when a property is set via $vo_post->property, the data type of the property is checked to insure data within the VO is of the correct datatype expected
 * values: id(int), title(string), author(string), content(string), categoryId(int), datePosted(string), commentList(array)
 * 
 * 
 * @author adamrensel
 *
 */
class VO_post
{
	private $id;
	private $userId;
	private $userName;
	private $content;
	private $title;
	private $categoryId;
	private $categoryName;
	private $datePosted;
	private $numComments;
	private $numNewComments;
	private $commentList;
	private $tagList;
	
	public function __construct($_id=NULL, 
								$_userId=NULL, 
								$_userName=NULL,
								$_content=NULL, 
								$_title=NULL, 
								$_categoryId=NULL,
								$_categoryName=NULL, 
								$_datePosted=NULL, 
								$_numComments=NULL,
								$_numNewComments=NULL,
								$_commentList=NULL,
								$_tagList=NULL)
	{
		$this->id = $_id;
		$this->userId = $_userId;
		$this->userName = $_userName;
		$this->content = $_content;
		$this->title = $_title;
		$this->categoryId = $_categoryId;
		$this->categoryName = $_categoryName;
		$this->datePosted = $_datePosted;
		$this->numComments = $_numComments;
		$this->numNewComments = $_numNewComments;
		$this->commentList = $_commentList;
		$this->tagList = $_tagList;
	}
	
	//getter
	public function __get($key)
	{
		return $this->$key;
	}//end __get()
	
	//setter
	public function __set($property,$value)
	{
		//checks to make sure the property exists within the class
		if(!property_exists($this, $property))
		{
			throw new Exception($property .' property does not exist in this class');
		}
		
		//check for data types
		switch ($property){
			//these are string values
			case "title":
			case "content":
			case "datePosted":
			case "categoryName":
			case "userName":
				if(!is_string($value) && !is_null($value)){
					throw new Exception("The $property property requires a string, the value $value is not a string ");
				}
			break;
			//these are int values
			case "id":
			case "categoryId":
			case "userId":
			case "numComments":
			case "numNewComments":
				if(!is_int($value) && !is_null($value)){
					throw new Exception("The $property property requires an int, the value $value is not a int ");
				}
			break;
			//these are array values
			case "commentList":
			case "tagList":
				if(!is_array($value) && !is_null($value)){
					throw new Exception("The $property property requires an array, the value $value is not an array ");
				}
			break;
		}//end switch
				
		$this->$property = $value;
		
	}//end __set()
	
}//end class

