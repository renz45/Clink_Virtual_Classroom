<?php

class model_blog
{
	private $_dbHost; 
	private $_dbUsername;
	private $_dbPassword;
	private $_dbName;
	
	private $_mysqli;
	
	public function __construct()
	{
		set_include_path($_SERVER['DOCUMENT_ROOT']);
		require_once 'php/db.php';
		require_once 'php/initClasses.php';
		
		$this->_dbHost = $dbHost;
		$this->_dbUsername = $dbUsername;
		$this->_dbPassword = $dbPassword;
		$this->_dbName = $dbName;
		
		$this->_mysqli = new mysqli($this->_dbHost, $this->_dbUsername, $this->_dbPassword, $this->_dbName);
		
		if (mysqli_connect_errno()) {
			throw new Exception("db connection failed for the class model_blog <br/> \n ". mysqli_connect_error());
		}//end if
		
	}//end constructor
	
	//private methods
	/**
	 * 
	 * This function is used by the getComments method in order to take a list of comments and reorganize them into the proper tree structure which indicates which
	 * comments are replies to other comments, nesting VO_comments within other VO_comments in their replyList properties
	 * @param array $orginalCommentList - orginal array which values will be moved from to internal arrays
	 * @param array $_commentList - array to search through for the correct reply id
	 * @param VO_comment $_commentVO - VO_comment which is the subject of the search
	 */
	private function _organizeReplies(&$orginalCommentList,$_commentList,$_commentVO){
		for ($i=0;$i < count($_commentList);$i++){
			if(($_commentVO->replyToCommentId) == ($_commentList[$i]->id)){
				//get the array from the vo_comment
				$arrayToPush = $_commentList[$i]->replyList;
				//add the new vo_comment to the array
				$arrayToPush[] = $_commentVO;
				//re-insert the array back into the vo, while preserving existing values
				$_commentList[$i]->replyList = $arrayToPush;
				
				//delete reply from the orginal aray
				unset($orginalCommentList[array_search($_commentVO, $orginalCommentList)]);
				//fix the hole in the array keys
				$orginalCommentList = array_values($orginalCommentList);
				//array_splice($_commentList, array_search($_commentVO, $_commentList),1);
				
			}elseif (count($_commentList[$i]->replyList) > 0){
				$this->_organizeReplies($orginalCommentList,($_commentList[$i]->replyList),$_commentVO);
			}//end elseif
		}//end foreach
	}//end organizeReplies
	
	/**
	 * 
	 * This method is to get around the magic quotes issue, if the get_magic_quotes_gpc() is true than real_escape_string is not called.
	 * @param string $string
	 */
	private function strip_slashes_GPC($string){
		if(!get_magic_quotes_gpc()){
			$this->_mysqli->real_escape_string($string);
		}
		return $string;
	}
	//public methods
	/**
	 * 
	 * Closes the mysqli connection
	 */
	public function disconnect() {
		$this->_mysqli->close();
	}
	
	/**
	 * 
	 * adds a category to the db
	 * @param string(required) $name - name of category to be added
	 * @throws Exception - if there is some sort of error related to a database connection issue or sql error
	 */
	public function addCategory($name)
	{
		//connect to the DB
		$mysqli = $this->_mysqli;
		
		
		//prepare the sql statement
		$sql = "INSERT INTO
					ih_categories
				SET
					name=?";
		
		if ($query = $mysqli->prepare($sql)){
			//bind query params
			$query->bind_param('s', $this->strip_slashes_GPC(htmlentities($name)));
			//run query
		    $query->execute();
		    
		    if($query->errno){
		    	throw new Exception("Mysql failed to add". $_GET['name'] ."to the db, error: ". $query->error);
		    }else{
		    	return array('name'=>$_GET['name'],'id'=>$query->insert_id);
		    }//end if
		
		    //close the query
		    $query->close();
		}else{
			throw new Exception($mysqli->error);	
		}//end if ($query = $mysqli->prepare($sql))
		
	}//end addCategory()
	
	/**
	 * 
	 * returns all categories in an assoc array - catName=>catId,catName=>catId
	 * @throws Exception - if there is some sort of error related to a database connection issue or sql error
	 */
	public function getCategories()
	{
		//connect to the DB
		$mysqli = $this->_mysqli;
		
		//test to make sure connection was complete
		
		
		//prepare the sql statement
		$sql = "SELECT
					id,
					name
				FROM
					ih_categories
				ORDER BY
					name";
		
		if ($query = $mysqli->prepare($sql)){
			
			//run query
		    $query->execute();
		    $query->store_result();
		
			if($query->errno){
				throw new Exception($query->error);
			}
		    
		   //bind variables to output
		    $query->bind_result($id,$name);
		
		    //fetch values, and create an assoc array to hold them for return
		    $categoryList = array();
		    while ($query->fetch()) {
		    	$categoryList[$name] = $id;
		    }//end while
		
		    //close the query
		    $query->close();
		}else{
			throw new Exception($mysqli->error);	
		}//end if ($query = $mysqli->prepare($sql))
		
	
		if(isset($categoryList)){
			return $categoryList;
		}//end if
	}//end getCategories
	
	/**
	 * 
	 * adds a tag to the db
	 * @param string(required) $name - name of tag to be added
	 * @throws Exception - if there is some sort of error related to a database connection issue or sql error
	 */
	public function addTag($name)
	{
		//connect to the DB
		$mysqli = $this->_mysqli;
		
		//prepare the sql statement
		$sql = "INSERT INTO
					ih_tags
				SET
					name=?";
		
		if ($query = $mysqli->prepare($sql)){
			//bind query params
			$query->bind_param('s', $this->strip_slashes_GPC(htmlentities($name)));
			//run query
		    $query->execute();
		    
		    if($query->errno){
		    	throw new Exception("Mysql failed to add". $_GET['name'] ."to the db, error: ". $query->error);
		    }else{
		    	return array('name'=>$_GET['name'],'id'=>$query->insert_id);
		    }//end if
		
		    //close the query
		    $query->close();
		}else{
			throw new Exception($mysqli->error);	
		}//end if ($query = $mysqli->prepare($sql))
		
		
	}//end addTag()
	
	/**
	 * 
	 * returns all tags in an assoc array - tagName=>tagId,tagName=>tagId
	 * @throws Exception - if there is some sort of error related to a database connection issue or sql error
	 */
	public function getTags()
	{
		//connect to the DB
		$mysqli =  $this->_mysqli;
		
		
		//prepare sql statement
		$sql = "SELECT
					id,
					name
				FROM
					ih_tags
				ORDER BY
					name";
		if($query = $mysqli->prepare($sql)){
			
			//run query
			$query->execute();
			$query->store_result();
			
			if($query->errno){
				throw new Exception($query->error);
			}
			
			//bind variables to output
			$query->bind_result($id,$name);
			
			//fetch values, and create an assoc array to hold them for return
			$tagList = array();
			while($query->fetch()){
				$tagList[$name] = $id;
			}//end while
			
			//close query
			$query->close();
		}else{
			throw new Exception($mysqli->error);	
		}//end if($query = $mysqli->prepare($sql))

		if(isset($tagList)){
			return $tagList;
		}//end if
	}// end getTags

	/**
	 * 
	 * Returns an assoc array - array(count=>Total count of posts available,postList=>array of VO_post) based on given options
	 * @param int $page - page number
	 * @param int $postsPerPage - number of posts per page
	 * @param int $postId - post id to return, if this is set then only one VO_post will be in the array
	 * @param int $categoryId - only returns posts with set category id
	 * @param int $tagId -  only returns posts with set tag id
	 * @param boolean $orderByNewComments - orders the posts returned by the number of new comments instead of date.
	 * @throws Exception - on database connection and access errors
	 */
	public function getPosts($page,$postsPerPage,$postId=NULL,$categoryId=NULL,$tagId=NULL,$orderByNewComments=false,$getComments=false,$onlyNewComments = false)
	{
		//sets the page start point based on the page number and posts per page variables - $page, $postsPerPage
		$pageStartPoint = ($page-1)*$postsPerPage;
		
		//connect to the DB
		$mysqli = $this->_mysqli;
		
		
		
		//this query builds the initial post list array and sorts by either date or the highest number of new comments
		//prepare the sql statement
		$sql = " SELECT
					p.id,
					p.title,
					p.content,
					p.date_posted,
					p.category_id,
					p.user_id,
					
					u.username,
					
					c.name AS categoryName,
					
					(SELECT
						COUNT(*)
					 FROM
						ih_comments AS c2
					 INNER JOIN ih_comments_to_posts AS cp ON(c2.id = cp.comment_id)
					 WHERE
					 	cp.post_id = p.id
					 ) AS commentTotalCount";
		
		//we want to order by the number of new comments, so this subquery returns a count of new comments for each post
					   //subquery
		$sql .=		" ,(SELECT
						COUNT(*)
					 FROM
						ih_comments AS c2
					 INNER JOIN ih_comments_to_posts AS cp ON(c2.id = cp.comment_id) AND (c2.is_read = false)
					 WHERE
					 	cp.post_id = p.id
					 ) AS newCommentCount";
		
		//build sql for the query to count total posts, used for pagination
		$sqlForCount = "SELECT COUNT(*)";
		
		
		$sqlFrom =	" FROM
					ih_posts AS p
				INNER JOIN ih_users AS u ON(p.user_id = u.id)
				LEFT JOIN ih_categories as c ON(p.category_id = c.id)";
		$sql .= $sqlFrom;
		$sqlForCount .= $sqlFrom;
		//if tagId categoryId or postId sort values are given, insert where statement with matching comparisons
		if(isset($tagId) || isset($categoryId) || isset($postId)){
			$sqlWhere = " WHERE ";
			
			$numWhere = 0;
			//return only posts with the tag id specified
			if(isset($tagId)){	
				//? = $tagId
				$sqlWhere .=	" p.id IN (SELECT post_id FROM ih_posts_to_tags WHERE tag_id= ? GROUP BY post_id )";
				$numWhere ++;
			}//end if
			
			
			if(isset($categoryId)){	
				if($numWhere > 0){
					$sqlWhere .= " AND ";
					$numWhere = 0;
				}//end if
				//? = $categoryId
				$sqlWhere .=	" p.category_id = ? ";
				$numWhere ++;
			}//end if

			if(isset($postId)){	
				if($numWhere > 0){
					$sqlWhere .= " AND ";
					$numWhere = 0;
				}//end if
				//? = $postId
				$sqlWhere .=	" p.id = ? ";
			}//end if
			$sql .= $sqlWhere;
			$sqlForCount .= $sqlWhere;
		}// end if(isset($tagId) || isset($categoryId) || isset($postId))	
		$sql .=	"ORDER BY";

		//we want to order by the number of new comments, sort by the posts largest number of new posts, to smallest
		if($orderByNewComments){
			$sql .=		" newCommentCount DESC ";
		}else{
			//or just sort by date
			$sql .= 	" date_posted DESC ";
		}//end if($orderByNewComments)
		
		//return the posts for the correct page
		if(!isset($postId)){
			//?'s = $page  $postsPerPage  $postsPerPage
			$sql .= 	" LIMIT ?,? ";
		}//end if
			
			
		//prepare the $query statement
		 if ($query = $mysqli->prepare($sql)){
			
		 	$bindList = array();
		 	$bindTypeList = array();
		 	//dynamically create the bind_params
			if(isset($tagId)){
				
				$bindList[] = (int)$tagId;
				$bindTypeList[] = 'i';
				
			}//end if
			
			if(isset($categoryId)){
				
				$bindList[] = (int)$categoryId;
				$bindTypeList[] = 'i';
			}//end if
			
			if(isset($postId)){
				
				$bindList[] = (int)$postId;
				$bindTypeList[] = 'i';
			}//end if
			
			if(!isset($postId)){
				
				$bindList[] = (int)$pageStartPoint;
				$bindTypeList[] = 'i';
				$bindList[] = (int)$postsPerPage;
				$bindTypeList[] = 'i';
				
			}//end if
			$bindInfo = array(implode("", $bindTypeList));
			$bindInfo = array_merge($bindInfo,$bindList);
			
			//call bind param function and pass in params
			call_user_func_array (array($query,'bind_param'),$bindInfo); 
		 	
			
			//run query
		    $query->execute();
			
		    $query->store_result();
		    
			if($query->errno){
				throw new Exception($query->error);
			}//end if
		    
			
		   //bind variables to output
		   $query->bind_result($idPost,$titlePost,$contentPost,$date_postedPost,$categoryIdPost,$userIdPost,$usernamePost,$categoryNamePost,$commentTotalCount,$NewCommentCountPost);
			
		    //fetch values, and create an array of VO_post
		    $postList = array();
		    while($query->fetch()){
		    	$postVO = new VO_post();
		    	$postVO->id = $idPost;
		    	$postVO->userId = $userIdPost;
		    	$postVO->userName = $usernamePost;
		    	$postVO->content = stripcslashes(html_entity_decode($contentPost));
		    	$postVO->title = $titlePost;
		    	$postVO->categoryId = $categoryIdPost;
		    	$postVO->categoryName = $categoryNamePost;
		    	$postVO->datePosted = $date_postedPost;
		    	$postVO->numComments = $commentTotalCount;
		    	$postVO->numNewComments = $NewCommentCountPost;
		    	
		    	$postList[] = $postVO;
		    	$postVO = NULL;
		    }//end while
		    
			
		    //close the query
		    $query->close();
		}else{
			throw new Exception($mysqli->error);	
		}//end if ($query = $mysqli->prepare($sql))
		
		//end build post list query
		
		
		//make a new query to find the total count of posts found in the first query, without the LIMIT clause
		
		//prepare the $query statement
		 if ($query = $mysqli->prepare($sqlForCount)){
		 	
		 	$bindList = array();
		 	$bindTypeList = array();
		 	//dynamically create the bind_params
			if(isset($tagId)){
				
				$bindList[] = (int)$tagId;
				$bindTypeList[] = 'i';
				
			}//end if
			
			if(isset($categoryId)){
				
				$bindList[] = (int)$categoryId;
				$bindTypeList[] = 'i';
			}//end if
			
			if(isset($postId)){
				
				$bindList[] = (int)$postId;
				$bindTypeList[] = 'i';
			}//end if
			
			
			$bindInfo = array(implode("", $bindTypeList));
			$bindInfo = array_merge($bindInfo,$bindList);
			
			
			//call bind param function and pass in params
			if(!empty($bindInfo[0])){
				call_user_func_array (array($query,'bind_param'),$bindInfo); 
			}//end if
		 	
			
			//run query
		    $query->execute();
			
		    $query->store_result();
		    
			if($query->errno){
				throw new Exception($query->error);
			}//end if
		    
			
		   //bind variables to output
		   $query->bind_result($count);
		   
			
		    //fetch values, store count to $postCount
		    $postCount = 0;
		    while($query->fetch()){
		    	$postCount = $count;
		    }//end while
		    
			
		    //close the query
		    $query->close();
		}else{
			throw new Exception($mysqli->error);	
		}//end if ($query = $mysqli->prepare($sql))
		
		
		
		//end get post total count
		
		
		//this query loops through the $postList array and attaches a list of tags(if any) to each VO_post contained in the array
		$sql = "SELECT
					t.id,
					t.name
				FROM
					ih_tags AS t
				INNER JOIN ih_posts_to_tags as pt ON(pt.tag_id = t.id) AND (pt.post_id = ?) 
				ORDER BY 
					t.name";
		
		//prepare the $query statement
		 if ($query = $mysqli->prepare($sql)){
		 	
		 
		 	for ($i=0;$i < count($postList);$i++)
		 	{
		 		
			 	$query->bind_param('i', ($postList[$i]->id));
				
				//run query
			    $query->execute();
				
			    $query->store_result();
			    
				if($query->errno){
					throw new Exception($query->error);
				}//end if
			    
				
			   //bind variables to output
			   $query->bind_result($idTag,$nameTag);
			   
				
			    //fetch values, store count to $postCount
			   $tagList = array();
			    while($query->fetch()){
			    	$tagList[$nameTag] = $idTag;
			    }//end while
			    $postList[$i]->tagList = $tagList;
		 	}//end foreach
			
		    //close the query
		    $query->close();
		}else{
			throw new Exception($mysqli->error);	
		}//end if ($query = $mysqli->prepare($sql))
		
		//end attach tag list query
		
		
		//attach comment list
		//$getComments=false,$onlyNewComments
		if($getComments){
			for($i=0;$i<count($postList);$i++){
				
				$postList[$i]->commentList = $this->getComments($postList[$i]->id, $onlyNewComments);
				
			}
		}//end if($getComments)
		
		//end attach comment list
		
		//package up the $postList and $postCount into an assoc array to return
		return array('postList'=>$postList,'count'=>$postCount);
	}//end getPosts()
	
	/**
	 * 
	 * Enter adds a post to the DB
	 * @param VO_post $post
	 * @throws Exception - if the object type of $post is not equal to a VO_post, and if there is some sort of error related to a database connection issue or sql error
	 */
	public function addPost($post)
	{
		//tests to make sure the $post var passed in is an instance of the VO_post, if not an exception is thrown.
		if(!($post instanceof VO_post)){
			throw new Exception('The addPost() method requires an instance of VO_post - '.$post. 'is not a VO_post and is invalid. ');
		}
		
		//connect to the DB
		$mysqli = $this->_mysqli;
		
		
		//insert blog data
		//prepare sql statement
		$sql = "INSERT INTO
					ih_posts
				SET
					title=?,
					content=?,
					date_posted=NOW(),
					user_id=?,
					category_id=?";
		if($query = $mysqli->prepare($sql)){
		
			if (($post->categoryId) == 0){
				$post->categoryId = NULL;
			}
		
			//bind query params
			$query->bind_param('ssii', $this->strip_slashes_GPC(htmlentities($post->title)), $this->strip_slashes_GPC(htmlentities($post->content)), ($post->userId), ($post->categoryId));
			
			//run query
			$query->execute();
			
			//if there was an error, return the error else story the id of the post added for return later
			if($query->errno){
				throw new Exception($query->error);
			}else{
				//store id of added post for return
				$postInsertId = $query->insert_id;
			}
			
			//close query
			$query->close();
		}else{
			throw new Exception($mysqli->error);	
		}//end if($query = $mysqli->prepare($sql))
		//end blog insert 
		
		//insert tag information
		if(!empty($post->tagList[0]))
		{
			//prepare sql statement
			$sql = "INSERT INTO
						ih_posts_to_tags
					SET
						post_id=?,
						tag_id=?";
			
			if($query = $mysqli->prepare($sql)){
				//loop through the array of tag ids in the $post object and add a new row to ih_posts_to_tags table
				foreach(($post->tagList) as $tagId){
					//bind query params
					$query->bind_param('ii', $postInsertId, $tagId);
					
					//run query
					$query->execute();
				}//end foreach
				
				//if an error happened, return the error
				if($query->errno){
					echo $query->error;
					echo "\n $post->tagList";
					throw new Exception("Something went wrong adding tags to db, error: ". ($query->error));
				}
				
				//close query
				$query->close();
			}//end if($query = $mysqli->prepare($sql))
		}//end if !empty($post->tagList[0])
		//end insert tag information
		
		//return the added id
		return $postInsertId;
		
		
	}//end addPost()

	/**
	 * 
	 * returns comments for a given post id
	 * @param int $postId - id of post for comments to be returned
	 * @param boolean $onlyNew - if true, only posts where is_read = false will be returned, this indicates a new post
	 * @throws Exception
	 */
	public function getComments($postId,$onlyNew=false){
		//connect to the DB
		$mysqli = $this->_mysqli;
		
		
		//prepare sql statement
		$sql = " SELECT
					c.id,
					c.author,
					c.content,
					c.email,
					c.website,
					c.notify_author,
					c.is_read,
					c.date_posted,
					c.reply_to_comment_id
				FROM
					ih_comments AS c
				INNER JOIN ih_comments_to_posts as cp ON(cp.comment_id = c.id) AND (cp.post_id = ?) ";
		if($onlyNew){
			$sql .=	" WHERE 
						c.is_read = false ";
		}
		$sql .=	" ORDER BY
					c.id ";
		
		if($query = $mysqli->prepare($sql)){
			
			$query->bind_param('i', $postId);
			
			//run query
			$query->execute();
			$query->store_result();
			
			if($query->errno){
				throw new Exception($query->error);
			}
			
			//bind variables to output
			$query->bind_result($id, $author, $content, $email, $website, $notify_author, $is_read, $date_posted, $reply_to_comment_id);
			
			
			//fetch values, and create an assoc array to hold them for return
			$commentList = array();
			while($query->fetch()){
				$commentVO = new VO_comment();
				$commentVO->id = $id;
				$commentVO->author = $author;
				$commentVO->content = $content;
				$commentVO->email = (string)$email;
				$commentVO->website = (string)$website;
				$commentVO->notifyAuthor = (bool)$notify_author;
				$commentVO->datePosted = $date_posted;
				$commentVO->replyToCommentId = $reply_to_comment_id;
				
				$commentList[] = $commentVO;
				$commentVO = NULL;
			}//end while
			
			
			
			//loop through all the comments and place the comment replies into the appropriate VO_comment
			if(!$onlyNew){
				foreach ($commentList as $comment){
					$this->_organizeReplies($commentList,$commentList,$comment);
				}
			}//end if

			//close query
			$query->close();
		}else{
			throw new Exception($mysqli->error);	
		}//end if($query = $mysqli->prepare($sql))
		
		
		if(isset($commentList)){
			return $commentList;
		}//end if
	}//end getComments
	
	
	
}//end model_blog