$(function(){
		
		imageFolderPath = 'upload';
		finalImageName = "";
	
		function updateImageList(defaultSelect){
			
			$('#imageUploadPreview').hide();
			
			imageList = $('#imageList').empty().hide();
			
			updateTimer = setInterval(function(){
				clearInterval(updateTimer);
				
				finalImageName = $('#frame').contents().find('#finalImageNameIframe').html();
				
				$.getJSON('getImageList.php',{folder:imageFolderPath},function(response){	
					
					
					listContents = "";
					for(i in response)
					{
						
						if(finalImageName == imageFolderPath+"/"+response[i]){
							
							listContents += '<option id="'+response[i]+'" selected="selected">'+response[i]+'</option>';
						}else{
							listContents += '<option id="'+response[i]+'">'+response[i]+'</option>';
						}
					}
					imageList.append(listContents);
					imageList.fadeIn();
					$('#imageUploadPreview').fadeIn();
					imageList.trigger('change');
					$(":button:contains('Ok')").attr("disabled","false").show();
				});//end getJSON
			},2000);//end getList()
			
		};
		updateImageList();
		
		$('#imageList').bind('change',function(){
			
				$('#imageUploadPreview').attr('src',imageFolderPath+"/"+$(this).val());
			
		});
		
		
	
				// Dialog			
		$('#dialog').dialog({
					autoOpen: false,
					width: 620,
					position:['center',20],
					closeText:'&#8855;',
					open: function(event, ui) { $(".ui-dialog-titlebar-close").hide(); },
					title:'Choose an Image',
					buttons: {
						"Ok": function() { 
							$(this).dialog("close");
							
							$('#frame').empty();
							
							$("#dialogForms").height('auto').show();
							$('#imageUploadFile').Attr('value','');
						},
						"Close": function() { 
							$(this).dialog("close"); 
							$('#frame').empty();
							
							$("#dialogForms").height('auto').show();
							$('#imageUploadFile').Attr('value','');
						}
						
					}
				});
				
				$('#imageUploadFile').bind('change',function(){
					$('#imageUploadSubmit').trigger('click');
					

				});
		
				
				// Dialog Link
				$('#dialog_link').click(function(){
					$('#dialog').dialog('open');
					return false;
				});
				
				
				$('#imageUploadSubmit').hide().bind('click',function(){
					
					$(":button:contains('Ok')").attr("disabled","disabled").hide(); 
					
					$('#frame').animate({'height':'400'},1000);
					$("#dialogForms").animate({'height':'0'},1000,function(){
						$("#dialogForms").hide();
					});
				});
				
				//waits for iframe to finish loading and reaches inside to attach events
				$().ready(function () {
					 //The function below executes once the iframe has finished loading
					$("#frame").load(function () {
						//save picture button
						$('#frame').contents().find('#savePicture').bind('click',function(){

								//console.log('click save');
								$("#dialogForms").height('auto').fadeIn();
								$('#frame').height(0);
								
								
								updateImageList(finalImageName);
								
							});
						 //discard button
						 $('#frame').contents().find('#deletePicture').bind('click',function(){
							 //$("#dialogForms").show().animate({'height':'30'},1000);
							 $("#dialogForms").height('auto').fadeIn();
							$('#frame').height(0);
						 });

					    });//end load
				});//end ready
			
				
				
				
				
				
				
				
				

				
});//end file