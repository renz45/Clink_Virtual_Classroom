<?php

$dirname = $_GET['folder'];
$dir = opendir($dirname);

$fileList = array();

while(false != ($file = readdir($dir)))
{
	if(($file != ".") and ($file != ".."))
	{
		array_push($fileList, $file);
	}
}

echo json_encode($fileList);