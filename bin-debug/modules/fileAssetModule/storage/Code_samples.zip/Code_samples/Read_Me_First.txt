HTML/CSS - raw, unsliced HTML for the Intentional Health site.

OOP_PHP - Object oriented php example. In progress, Intentional Health site, currently the back-end/admin is around 70% complete.

HTML5/Procedural_PHP - World surf mobile site, the working version can be found at http://www.adamrensel.com/worldsurfmobile/index.php