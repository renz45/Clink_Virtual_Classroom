		<p id="linkMainSite"><a href="#">View Main Site</a></p>
		<div id="footer">
			<p>Copyright World Surf, 2010</p>
		</div><!-- end footer -->	
	</body>
</html>